Compile:
gcc sobel_pthread.c -lm -pthread -o sobel_pthread
gcc sobel_openmp.c -lm -fopenmp -o sobel_openmp
gcc rw.c -pthread -o rw

Run:
./sobel_pthread NGGYU.jpg <num_of_threads>
./sobel_openmp NGGYU.jpg <num_of_threads>
./rw

pthreads: rows are split evenly between threads and the leftover rows go to the first few threads. Timed with clock_gettime.

OpenMP: used parallel for with collapse(2) on the row and column loops. Timed with omp_get_wtime.

rw lock: readers wait if a writer is waiting so writers dont starve. When a writer finishes, waiting readers go first so readers dont starve.
