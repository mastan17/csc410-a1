#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

int Gx[3][3] = {
    {-1, 0, 1},
    {-2, 0, 2},
    {-1, 0, 1}
};

int Gy[3][3] = {
    {-1, -2, -1},
    { 0,  0,  0},
    { 1,  2,  1}
};

typedef struct {
    unsigned char *input;
    unsigned char *output;
    int width;
    int start_row;
    int end_row;
} thread_data;

// each thread does rows start_row to end_row
void *convolve_sobel_color(void *arg)
{
    thread_data *d = (thread_data *)arg;
    unsigned char *input = d->input;
    unsigned char *output = d->output;
    int width = d->width;

    int k_offset = 1;
    int channels = 3; // 3 channels - red blue green

    for (int i = d->start_row; i < d->end_row; i++) {
        for (int j = k_offset; j < width - k_offset; j++) {
            
            // looping through each color channel separately
            for (int c = 0; c < channels; c++) {
                float sum_x = 0.0f;
                float sum_y = 0.0f;
                
                for (int ki = 0; ki < 3; ki++) {
                    for (int kj = 0; kj < 3; kj++) {
                        int pixel_row = i + (ki - k_offset);
                        int pixel_col = j + (kj - k_offset);
                        
                        // position in flat interleaved array is (Row * Width + Col) * 3 + Channel
                        int pixel_idx = (pixel_row * width + pixel_col) * channels + c;
                        unsigned char pixel_val = input[pixel_idx];
                        
                        sum_x += (float)pixel_val * Gx[ki][kj];
                        sum_y += (float)pixel_val * Gy[ki][kj];
                    }
                }
                
                float magnitude = sqrtf((sum_x * sum_x) + (sum_y * sum_y));
                
                // multiplying edge intensity by 2.0 to make neon bloom stand out :)
                magnitude *= 2.0f; 
                
                if (magnitude > 255.0f) magnitude = 255.0f;
                if (magnitude < 0.0f) magnitude = 0.0f;
                
                // Write directly back to corresponding output color byte
                int out_idx = (i * width + j) * channels + c;
                output[out_idx] = (unsigned char)magnitude;
            }
        }
    }
    return NULL;
}

int main(int argc, char *argv[]) 
{
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <input_image_path> <num_of_threads>\n", argv[0]);
        return EXIT_FAILURE;
    }

    char *input_path = argv[1];
    int num_threads = atoi(argv[2]);
    int width, height, actual_channels;

    printf("Loading color image: %s...\n", input_path);
    // Request 3 channels (RGB) explicitly
    unsigned char *input_image = stbi_load(input_path, &width, &height, &actual_channels, 3);
    
    if (!input_image) 
    {
        fprintf(stderr, "Error: Could not load image file.\n");
        return EXIT_FAILURE;
    }

        
    // Allocate the output image memory buffer (Width * Height * 3 bytes)
    unsigned char *output_image = (unsigned char*)calloc(width * height * 3, sizeof(unsigned char));

    printf("Running Sobel operator with %d threads...\n", num_threads);

    pthread_t threads[num_threads];
    thread_data data[num_threads];

    // split rows 1 to height-2 evenly, first threads get the leftover rows
    int rows = (height - 2) / num_threads;
    int extra = (height - 2) % num_threads;

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    int row = 1;
    for (int t = 0; t < num_threads; t++) {
        data[t].input = input_image;
        data[t].output = output_image;
        data[t].width = width;
        data[t].start_row = row;
        row += rows + (t < extra ? 1 : 0);
        data[t].end_row = row;
        pthread_create(&threads[t], NULL, convolve_sobel_color, &data[t]);
    }

    for (int t = 0; t < num_threads; t++)
        pthread_join(threads[t], NULL);

    clock_gettime(CLOCK_MONOTONIC, &end);
    double elapsed_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
    printf("Time taken with pthreads: %.6f seconds\n", elapsed_time);

    // Save output 
    char *output_path = "output_sobel_pthread.bmp";
    stbi_write_bmp(output_path, width, height, 3, output_image);
    printf("Saved edge visual to '%s'\n", output_path);

    stbi_image_free(input_image);
    free(output_image);
    
    return 0;
}
